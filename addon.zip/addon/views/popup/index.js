(() => {
  "use strict";
  var __webpack_exports__ = {};
  let activeTabOrigin = "";
  const retrieveStorageObj = {
    rules: {},
    autoGroupTabs: false,
    showTabCount: false
  };
  chrome.storage.local.get(retrieveStorageObj, (result => {
    chrome.tabs.query({
      active: true,
      currentWindow: true
    }, (tabs => {
      const activeTab = tabs[0];
      const activeTabUrl = new URL(activeTab.url || activeTab.pendingUrl || "");
      activeTabOrigin = activeTabUrl.origin;
      const originInput = document.getElementById("tab-group-origin");
      const titleInput = document.getElementById("tab-group-title");
      const colorInput = document.getElementById("tab-group-color");
      originInput.value = activeTabOrigin;
      titleInput.value = result.rules[activeTabOrigin]?.title || "";
      colorInput.value = result.rules[activeTabOrigin]?.color || "";
    }));
    const autoGroupTabs = document.getElementById("autoGroupTabs");
    autoGroupTabs.checked = result.autoGroupTabs;
    const showTabCount = document.getElementById("showTabCount");
    showTabCount.checked = result.showTabCount;
    document.getElementsByName("options").forEach((element => {
      element.addEventListener("change", (event => {
        const target = event.target;
        const name = target.id;
        const value = target.checked;
        chrome.storage.local.set({
          [name]: value
        });
      }));
    }));
    const rules = result.rules;
    const rulesList = document.getElementById("rulesList");
    for (const [origin, properties] of Object.entries(rules)) {
      const ruleContainer = document.createElement("div");
      ruleContainer.classList.add("rule");
      const rule = {
        origin,
        properties
      };
      const ruleElement = document.createElement("li");
      ruleElement.innerText = `${rule.origin}`;
      const span = document.createElement("span");
      span.innerText = rule.properties.title;
      span.style.background = rule.properties.color;
      ruleElement.prepend(span);
      const deleteBtn = document.createElement("button");
      deleteBtn.innerText = "Delete";
      deleteBtn.addEventListener("click", (() => {
        chrome.storage.local.set({
          rules: {
            ...rules,
            [rule.origin]: void 0
          }
        });
        ruleContainer.remove();
      }));
      ruleContainer.appendChild(ruleElement);
      ruleContainer.appendChild(deleteBtn);
      rulesList.appendChild(ruleContainer);
    }
  }));
  const form = document.getElementById("addRuleForm");
  form.addEventListener("submit", (_event => {
    const formData = new FormData(form);
    const title = formData.get("title");
    const color = formData.get("color");
    chrome.storage.local.get({
      rules: {}
    }, (result => {
      chrome.storage.local.set({
        rules: {
          ...result.rules,
          [activeTabOrigin]: {
            title,
            color
          }
        }
      });
    }));
  }));
})();