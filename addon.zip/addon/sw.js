(() => {
  "use strict";
  var __webpack_exports__ = {};
  chrome.sidePanel.setPanelBehavior({
    openPanelOnActionClick: true
  }).catch((error => {}));
  chrome.runtime.onInstalled.addListener((() => {
    chrome.contextMenus.create({
      id: "openSidePanel",
      title: "Open side panel",
      contexts: [ "all" ]
    });
  }));
  chrome.contextMenus.onClicked.addListener(((info, tab) => {
    if (info.menuItemId === "openSidePanel") chrome.sidePanel.open({
      windowId: tab.windowId
    });
  }));
})();